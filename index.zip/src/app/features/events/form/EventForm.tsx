import { ChangeEvent, useState } from "react";
import { Button, Form, Header, Segment } from "semantic-ui-react";
import { AppEvent} from "../../../api/types/eventypes";
import { sampleData } from "../../../api/sampleData";

type Props = {
    changeState:(value:boolean)=>void;
    setEvents:(events:AppEvent[])=>void;
    events:AppEvent[];
  };
  

export default function EventForm({changeState,setEvents,events}:Props) {

    const intialState : AppEvent=
    {
        id:"",
        title:"",
        date:"",
        description:"",
        category:"",
        city:"",
        venue:"",
        hostedBy:"",
        hostPhotoURL:"",
        attendees:[]
    }

    const [value,setvalues]= useState(intialState);

    function OnSubmit()
    {
        setEvents([...events,value]);
        console.log(events)
    }

    function ChangeValues(e:ChangeEvent<HTMLInputElement>, prop: string) {
        setvalues({ ...value, [prop]: e.target.value });
      }

  return (
    
    <>
    <Segment clearing>
        <Header content="Create Event" />
        <Form onSubmit={OnSubmit}>
            <Form.Field>
            <input type="text" placeholder="Event Title" onChange={(e) => ChangeValues(e, "title")} />
            </Form.Field>
            <Form.Field>
            <input type="text" placeholder="Category" onChange={(e) => ChangeValues(e, "Category")} />
            </Form.Field>
            <Form.Field>
            <input type="text" placeholder="Description" onChange={(e) => ChangeValues(e, "Description")} />
            </Form.Field>
            <Form.Field>
            <input type="text" placeholder="City" onChange={(e) => ChangeValues(e, "City")} />
            </Form.Field>
            <Form.Field>
            <input type="text" placeholder="Venue" onChange={(e) => ChangeValues(e, "Venue")} />
            </Form.Field>
            <Form.Field>
            <input type="date" placeholder="Date" onChange={(e) => ChangeValues(e, "Date")} />
            </Form.Field>
            <Button type="submit" floated="right" positive content="Submit" />
            <Button type="button" floated="right" onClick={() => changeState(false)} content="Cancel" />
        </Form>
    </Segment>

    
  
  </>
  )
}