import { List,Image } from "semantic-ui-react";
import { Attendee } from "../../../api/types/eventypes";

type Props=
{
  attendee:Attendee
}

export default function EventListAttendeee({attendee}:Props) {
  return (
    <List.Item>
      <Image size="mini" circular src={attendee.photoURL}/>
    </List.Item>
  )
}