import { Grid } from "semantic-ui-react";
import EventList from "./EventList";
import EventForm from "../form/EventForm";

import { sampleData } from "../../../api/sampleData";
import { useEffect, useState } from "react";
import { AppEvent } from "../../../api/types/eventypes";

type Props = {
  isOpen: boolean;
  changeState:(value:boolean)=>void;
};


export default function EventDashboard({isOpen,changeState}:Props) {

  const [events,setEvents] = useState<AppEvent[]>([])

  useEffect(()=>
  {
      setEvents(sampleData)
  },[events])
 
  return (
    <Grid>
      <Grid.Column width={10}>
          <EventList events={events}/>
      </Grid.Column>
      <Grid.Column width={6}>
        {isOpen && <EventForm setEvents={setEvents} events={events} changeState={changeState}/>}
      </Grid.Column>
    </Grid>
  )
}
