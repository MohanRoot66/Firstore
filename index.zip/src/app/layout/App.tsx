
import "./styles.css"
import EventDashboard from "../features/events/dashboard/EventDashboard"
import NavBar from "./nav/NavBar"
import { Container } from "semantic-ui-react"
import { useState } from "react"


function App() {
  
  const [isOpen, changeState] = useState(false);
  return (
    <>
      <NavBar changeState={changeState}/>
      <Container className="main">
      <EventDashboard changeState={changeState} isOpen={isOpen}/>
      </Container>
      </>
  )
}

export default App
