
import "./styles.css"
import EventDashboard from "../features/events/dashboard/EventDashboard"
import NavBar from "./nav/NavBar"
import { Container } from "semantic-ui-react"
import { useState } from "react"
import { AppEvent } from "../api/types/eventypes"


function App() {
  
  const [formOpen, setFormOpen] = useState(false);
  const [selectedevent,setselectedevent]=useState<AppEvent | null>(null);

  function handleselectevent(event : AppEvent | null)
  {
    setselectedevent(()=>event);
    setFormOpen(true)
  }

  function handleCreateFormOpen()
  {
    setselectedevent(null);
    setFormOpen(true);
  }

  return (
    <>
      <NavBar changeState={handleCreateFormOpen}/>
      <Container className="main">
      <EventDashboard selectedevent={selectedevent} setselectedevent={handleselectevent} changeState={setFormOpen} isOpen={formOpen}/>
      </Container>
      </>
  )
}

export default App
