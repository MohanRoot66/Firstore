import { createBrowserRouter } from "react-router-dom";
import App from "../layout/App";
import EventDashboard from "../features/events/dashboard/EventDashboard";

export const router = createBrowserRouter(
    [
        {
            path:"/",
            element:<App/>,
            children:[
                {
                    path:"/events",element:<EventDashboard/>
                }
            ]
        }
    ]
)