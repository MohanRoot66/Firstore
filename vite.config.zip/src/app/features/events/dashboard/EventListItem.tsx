import { Button, Icon, Item, ItemGroup, List, Segment, SegmentGroup } from "semantic-ui-react";
import EventListAttendeee from "./EventListAttendeee";
import { AppEvent } from "../../../api/types/eventypes";

type Props=
{
  event:AppEvent
  setselectedevent:(event:AppEvent)=>void
  deleteEvent:(id:string)=>void;
}

export default function EventListItem({event,deleteEvent,setselectedevent}:Props) {
  return (
    <SegmentGroup>
      <Segment>
        <ItemGroup>
          <Item>
            <Item.Image size="tiny" circular src={event.hostPhotoURL || "/user.png"}/>
            <Item.Content>
              <Item.Header>{event.title}</Item.Header>
              <Item.Description>
                {event.hostedBy}
              </Item.Description>
            </Item.Content>
          </Item>
        </ItemGroup>
      </Segment>
      <Segment>
        <span>
          <Icon name="clock" /> {event.date}
          <Icon name="marker"/> {event.venue}
        </span>
      </Segment>
      <Segment secondary>
          <List horizontal>
            {event.attendees.map((attendee)=>
            (
              <EventListAttendeee attendee={attendee} key={attendee.id} />
            ))}
          </List>
      </Segment>
      <Segment clearing>
        <span>{event.description}</span>
        <Button color="red" floated="right" onClick={()=>deleteEvent(event.id)} content="delete"/>
        <Button color="teal" floated="right" onClick={()=>setselectedevent(event)} content="view"/>
        
      </Segment>
    </SegmentGroup>
  )
}