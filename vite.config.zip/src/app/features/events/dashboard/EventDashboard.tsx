import { Grid } from "semantic-ui-react";
import EventList from "./EventList";
import EventForm from "../form/EventForm";

import { sampleData } from "../../../api/sampleData";
import { useEffect, useState } from "react";
import { AppEvent } from "../../../api/types/eventypes";

type Props = {
  isOpen: boolean;
  changeState:(value:boolean)=>void;
  selectedevent:AppEvent | null;
  setselectedevent:(event:AppEvent | null)=>void
};


export default function EventDashboard({isOpen,changeState,selectedevent,setselectedevent}:Props) {

  const [events,setEvents] = useState<AppEvent[]>([]);
  

  useEffect(()=>
  {
      setEvents(sampleData)
  },[])
  
  function updateEvent(updatedEvent:AppEvent)
  {
    setEvents(events.map(evt=>evt.id===updatedEvent.id ? updatedEvent : evt))
    setselectedevent(null);
    changeState(false);
  }

  function deleteEvent(eventId:string)
  {
    setEvents(events.filter(evt=>evt.id!==eventId))
  }

  return (
    <Grid>
      <Grid.Column width={10}>
          <EventList deleteEvent={deleteEvent} setselectedevent={setselectedevent} events={events}/>
      </Grid.Column>
      <Grid.Column width={6}>
        {isOpen && <EventForm 
        setEvents={setEvents} selectedevent={selectedevent} events={events} changeState={changeState}
        key={selectedevent ? selectedevent.id : 'create'}
        updatedEvent={updateEvent}
        />}
      </Grid.Column>
    </Grid>
  )
}
