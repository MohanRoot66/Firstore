import { AppEvent } from "../../../api/types/eventypes";
import EventListItem from "./EventListItem";

type Props=
{
  events : AppEvent[]
  setselectedevent:(event:AppEvent)=>void
  deleteEvent:(id:string)=>void;
}

export default function EventList({events,deleteEvent,setselectedevent}:Props) {
  return (
    <>
    {events.map((event)=>(
      <EventListItem deleteEvent={deleteEvent} setselectedevent={setselectedevent} event={event} key={event.id}/>
    ))}
    </>
  )
}