export default function EventDetailedPage() {
  return (
    <div>EventDetailedPage</div>
  )
}
