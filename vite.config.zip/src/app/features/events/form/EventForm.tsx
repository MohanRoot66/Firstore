import { ChangeEvent, useState } from "react";
import { Button, Form, Header, Segment } from "semantic-ui-react";
import { AppEvent} from "../../../api/types/eventypes";
import { createId } from "@paralleldrive/cuid2";

type Props = {
    changeState:(value:boolean)=>void;
    setEvents:(events:AppEvent[])=>void;
    selectedevent:AppEvent | null;
    events:AppEvent[];
    updatedEvent:(event:AppEvent)=>void;
  };
  
 

export default function EventForm({changeState,selectedevent,setEvents,events,updatedEvent}:Props) {

    
    const intialState : AppEvent=
    selectedevent ??
    {
        id:createId(),
        title:"",
        date:"",
        description:"",
        category:"",
        city:"",
        venue:"",
        hostedBy:"",
        hostPhotoURL:"",
        attendees:[]
    }

    const [state,setvalues]= useState(intialState);

    function OnSubmit()
    {
      selectedevent ? updatedEvent({...selectedevent,...state}) :
        setEvents([...events,state]);
        changeState(false)
       
    }

    function ChangeValues(e:ChangeEvent<HTMLInputElement>, prop: string) {
        setvalues({ ...state, [prop]: e.target.value });
      }

  return (
    
    <>
    <Segment clearing>
        <Header content={selectedevent ? "update event" : "create event"} />
        <Form onSubmit={OnSubmit}>
            <Form.Field>
            <input type="text" placeholder="Event Title" value={state.title} onChange={(e) => ChangeValues(e, "title")} />
            </Form.Field>
            <Form.Field>
            <input type="text" placeholder="Category" value={state.category} onChange={(e) => ChangeValues(e, "category")} />
            </Form.Field>
            <Form.Field>
            <input type="text" placeholder="Description" value={state.description} onChange={(e) => ChangeValues(e, "description")} />
            </Form.Field>
            <Form.Field>
            <input type="text" placeholder="City" value={state.city} onChange={(e) => ChangeValues(e, "city")} />
            </Form.Field>
            <Form.Field>
            <input type="text" placeholder="Venue" value={state.venue}  onChange={(e) => ChangeValues(e, "venue")} />
            </Form.Field>
            <Form.Field>
            <input type="date" placeholder="Date" value={state.date} onChange={(e) => ChangeValues(e, "date")} />
            </Form.Field>
            <Button type="submit" floated="right" positive content="Submit" />
            <Button type="button" floated="right" onClick={() => changeState(false)} content="Cancel" />
        </Form>
    </Segment>

    
  
  </>
  )
}